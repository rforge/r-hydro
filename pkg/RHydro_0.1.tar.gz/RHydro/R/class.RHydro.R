
## This is a class that is very close to HydroRun
## but includes everything to run the model, such that generic
## functions such as simulate() become easy
## This class is similar to the hydromad object of the eponymous package
## 

setOldClass("xts")

setClass("RHydro",
         representation = representation(parameters="HydroModelParameters",
                                         observations = "xts",
                                         simulations = "list",
                                         metadata = "data.frame",
                                         performance = "data.frame",
                                         supportdata="list",
                                         model = "character"),
         validity =  validityRHydro,
         prototype = prototype(parameters = new("HydroModelParameters"),
                               simulations = xts(),
                               metadata = data.frame()),
                               GIS = NULL,
                               performanceMeasures=data.frame(),
                               modelSupportData = list(),
                               modelStructure = character())
         )    
)

validityRHydro <- function()

setMethod("simulate",
          signature(object = "RHydro"),
          function (object) 
          {
	    stop("ToDo: Not implemented")
          }
)
