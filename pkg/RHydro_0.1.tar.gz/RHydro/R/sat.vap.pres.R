sat.vap.pres <- function(temp){
	return(0.611*exp(17.3*temp/(temp+237.3)))
}

