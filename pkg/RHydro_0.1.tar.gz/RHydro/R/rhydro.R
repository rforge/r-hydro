
## construct an rhydro object ready for simulation

rhydro <- function(model, parameters, observations, supportdata){
  new("RHydro", rhydro@observations = observations,
  rhydro@supportdata = supportdata,
  rhydro@model = model)
}





