
## construct an rhydro object ready for simulation

rhydro <- function(parameters, data, supportdata = NULL, model,
                   performance = NULL, ...){
  new("RHydro",
      data = data,
      supportdata = supportdata,
      model = model,
      performance = performance,
      options = list(...))
}





